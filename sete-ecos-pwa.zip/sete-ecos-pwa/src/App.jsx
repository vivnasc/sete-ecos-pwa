import { useState, useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { supabase, auth } from './lib/supabase'

import Auth from './components/Auth'
import Navigation from './components/Navigation'
import Home from './pages/Home'
import LuminaPage from './pages/Lumina'

import './styles/global.css'

export default function App() {
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(null)
  const [userProfile, setUserProfile] = useState(null)
  
  useEffect(() => {
    // Verificar sessão actual
    checkSession()
    
    // Escutar mudanças de auth
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session?.user) {
          setUser(session.user)
          await loadUserProfile()
        } else {
          setUser(null)
          setUserProfile(null)
        }
      }
    )
    
    return () => subscription.unsubscribe()
  }, [])
  
  const checkSession = async () => {
    try {
      const { data: { session } } = await supabase.auth.getSession()
      if (session?.user) {
        setUser(session.user)
        await loadUserProfile()
      }
    } catch (error) {
      console.error('Erro ao verificar sessão:', error)
    } finally {
      setLoading(false)
    }
  }
  
  const loadUserProfile = async () => {
    try {
      const profile = await auth.getUserProfile()
      setUserProfile(profile)
    } catch (error) {
      console.error('Erro ao carregar perfil:', error)
    }
  }
  
  const handleAuth = async () => {
    await checkSession()
  }
  
  const handleLogout = async () => {
    await auth.signOut()
    setUser(null)
    setUserProfile(null)
  }
  
  if (loading) {
    return (
      <div className="app-loading">
        <h1>SETE ECOS</h1>
        <div className="loading-spinner" />
      </div>
    )
  }
  
  if (!user) {
    return <Auth onAuth={handleAuth} />
  }
  
  return (
    <BrowserRouter>
      <div className="app">
        <Routes>
          <Route 
            path="/" 
            element={<Home userProfile={userProfile} />} 
          />
          <Route 
            path="/lumina" 
            element={
              <LuminaPage 
                user={user} 
                userProfile={userProfile} 
              />
            } 
          />
          <Route 
            path="/ecos" 
            element={
              <div style={{ padding: '20px', textAlign: 'center' }}>
                <h2>Ecos</h2>
                <p>Em breve: VITALIS, SERENA, IGNIS, VENTIS, ECOA, IMAGO</p>
              </div>
            } 
          />
          <Route 
            path="/perfil" 
            element={
              <div style={{ padding: '20px' }}>
                <h2>Perfil</h2>
                <p><strong>Nome:</strong> {userProfile?.nome}</p>
                <p><strong>Email:</strong> {userProfile?.email}</p>
                <button onClick={handleLogout} style={{ marginTop: '20px', padding: '10px 20px' }}>
                  Sair
                </button>
              </div>
            } 
          />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
        
        <Navigation />
      </div>
    </BrowserRouter>
  )
}
