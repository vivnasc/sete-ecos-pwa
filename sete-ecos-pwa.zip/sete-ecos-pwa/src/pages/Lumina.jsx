import { useState, useEffect } from 'react'
import { lumina, ciclo } from '../lib/supabase'
import { gerarLeitura } from '../lib/lumina-leituras'
import LuminaCheckin from '../components/LuminaCheckin'
import LuminaLeitura from '../components/LuminaLeitura'
import './Lumina.css'

export default function LuminaPage({ user, userProfile }) {
  const [estado, setEstado] = useState('loading') // loading | checkin | leitura | historico
  const [checkinHoje, setCheckinHoje] = useState(null)
  const [leituraActual, setLeituraActual] = useState(null)
  const [cicloInfo, setCicloInfo] = useState(null)
  const [historico, setHistorico] = useState([])
  
  useEffect(() => {
    carregarDados()
  }, [userProfile])
  
  const carregarDados = async () => {
    try {
      // Calcular fase do ciclo
      if (userProfile?.ultimo_periodo) {
        const info = await ciclo.calcularFase(
          userProfile.ultimo_periodo,
          userProfile.duracao_ciclo
        )
        setCicloInfo(info)
      }
      
      // Verificar se já fez check-in hoje
      const hoje = await lumina.getTodayCheckin(userProfile.id)
      if (hoje) {
        setCheckinHoje(hoje)
        if (hoje.lumina_leituras?.[0]) {
          setLeituraActual(hoje.lumina_leituras[0])
          setEstado('leitura')
        } else {
          setEstado('checkin')
        }
      } else {
        setEstado('checkin')
      }
    } catch (error) {
      console.error('Erro ao carregar dados:', error)
      setEstado('checkin')
    }
  }
  
  const handleCheckinComplete = async (checkinData) => {
    try {
      // Gerar leitura
      const leituraData = gerarLeitura(checkinData)
      
      // Guardar check-in
      const checkin = await lumina.saveCheckin(userProfile.id, checkinData)
      
      // Guardar leitura
      const leitura = await lumina.saveLeitura(userProfile.id, checkin.id, leituraData)
      
      setCheckinHoje(checkin)
      setLeituraActual(leitura)
      setEstado('leitura')
    } catch (error) {
      console.error('Erro ao guardar check-in:', error)
      alert('Erro ao guardar. Tenta novamente.')
    }
  }
  
  const handleVerHistorico = async () => {
    try {
      const dados = await lumina.getCheckins(userProfile.id, 30)
      setHistorico(dados)
      setEstado('historico')
    } catch (error) {
      console.error('Erro ao carregar histórico:', error)
    }
  }
  
  const handleNovoCheckin = () => {
    setEstado('checkin')
    setLeituraActual(null)
  }
  
  if (estado === 'loading') {
    return (
      <div className="lumina-loading">
        <div className="lumina-loading-spinner" />
        <p>A carregar LUMINA...</p>
      </div>
    )
  }
  
  if (estado === 'checkin') {
    return (
      <LuminaCheckin 
        onComplete={handleCheckinComplete}
        cicloInfo={cicloInfo}
      />
    )
  }
  
  if (estado === 'leitura' && leituraActual) {
    return (
      <LuminaLeitura
        leitura={leituraActual}
        onVoltar={handleNovoCheckin}
        onVerHistorico={handleVerHistorico}
      />
    )
  }
  
  if (estado === 'historico') {
    return (
      <div className="lumina-historico fade-in">
        <div className="lumina-historico-header">
          <button onClick={() => setEstado('leitura')}>← Voltar</button>
          <h2>Histórico</h2>
        </div>
        
        <div className="lumina-historico-lista">
          {historico.length === 0 ? (
            <p className="lumina-historico-vazio">Ainda não tens check-ins registados.</p>
          ) : (
            historico.map((item) => (
              <div key={item.id} className="lumina-historico-item">
                <div className="lumina-historico-data">
                  {new Date(item.data).toLocaleDateString('pt-PT', {
                    weekday: 'short',
                    day: 'numeric',
                    month: 'short'
                  })}
                </div>
                <div className="lumina-historico-estados">
                  <span title="Corpo">{item.corpo === 'leve' ? '🦋' : item.corpo === 'pesado' ? '🪨' : '😐'}</span>
                  <span title="Energia">{item.energia === 'cheia' ? '✨' : item.energia === 'vazia' ? '🔋' : '😐'}</span>
                  <span title="Mente">{item.mente === 'silenciosa' ? '🧘' : item.mente === 'caotica' ? '🌪️' : '😐'}</span>
                </div>
                {item.lumina_leituras?.[0] && (
                  <div className="lumina-historico-padrao">
                    {item.lumina_leituras[0].padrao.replace(/_/g, ' ')}
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    )
  }
  
  return null
}
