import { Link } from 'react-router-dom'
import './Home.css'

export default function Home({ userProfile }) {
  const primeiroNome = userProfile?.nome?.split(' ')[0] || 'Viajante'
  
  return (
    <div className="home-page">
      <header className="home-header">
        <img 
          src="/logos/sete-ecos-logo.png" 
          alt="SETE ECOS" 
          className="home-logo"
        />
        <p className="home-greeting">Olá, {primeiroNome}</p>
      </header>
      
      <section className="home-lumina-card">
        <div className="home-lumina-icon">
          <img src="/logos/lumina-logo-icone.png" alt="LUMINA" />
        </div>
        <div className="home-lumina-content">
          <span className="home-lumina-label">Diagnóstico Diário</span>
          <h2>Como estás hoje?</h2>
          <p>LUMINA vê o teu estado actual e orienta-te para o Eco que mais precisas.</p>
          <Link to="/lumina" className="home-lumina-btn">
            Fazer Check-in
          </Link>
        </div>
      </section>
      
      <section className="home-ecos">
        <h3>Os Sete Caminhos</h3>
        
        <div className="home-ecos-grid">
          <div className="home-eco-card eco-vitalis">
            <span className="home-eco-numero">1</span>
            <span className="home-eco-name">VITALIS</span>
            <span className="home-eco-area">Corpo · Terra</span>
          </div>
          
          <div className="home-eco-card eco-serena">
            <span className="home-eco-numero">2</span>
            <span className="home-eco-name">SERENA</span>
            <span className="home-eco-area">Emoção · Água</span>
          </div>
          
          <div className="home-eco-card eco-ignis">
            <span className="home-eco-numero">3</span>
            <span className="home-eco-name">IGNIS</span>
            <span className="home-eco-area">Vontade · Fogo</span>
          </div>
          
          <div className="home-eco-card eco-ventis">
            <span className="home-eco-numero">4</span>
            <span className="home-eco-name">VENTIS</span>
            <span className="home-eco-area">Ritmo · Ar</span>
          </div>
          
          <div className="home-eco-card eco-ecoa">
            <span className="home-eco-numero">5</span>
            <span className="home-eco-name">ECOA</span>
            <span className="home-eco-area">Expressão · Éter</span>
          </div>
          
          <div className="home-eco-card eco-lumina">
            <span className="home-eco-numero">6</span>
            <span className="home-eco-name">LUMINA</span>
            <span className="home-eco-area">Visão · Luz</span>
          </div>
          
          <div className="home-eco-card eco-imago">
            <span className="home-eco-numero">7</span>
            <span className="home-eco-name">IMAGO</span>
            <span className="home-eco-area">Identidade · Consciência</span>
          </div>
        </div>
      </section>
      
      <footer className="home-footer">
        <p>Uma travessia. Sete caminhos. Tu decides.</p>
      </footer>
    </div>
  )
}
