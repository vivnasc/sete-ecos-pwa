import { ECOS_INFO } from '../lib/lumina-leituras'
import './Lumina.css'

export default function LuminaLeitura({ leitura, onVoltar, onVerHistorico }) {
  const eco = ECOS_INFO[leitura.eco_sugerido] || ECOS_INFO.nenhum
  
  return (
    <div className="lumina-leitura fade-in">
      <div className="lumina-leitura-header">
        <span className="lumina-leitura-label">A tua leitura de hoje</span>
        <h2>✨ LUMINA vê</h2>
      </div>
      
      <div className="lumina-leitura-card">
        <p className="lumina-leitura-texto">{leitura.texto_leitura}</p>
      </div>
      
      {leitura.eco_sugerido !== 'nenhum' && (
        <div className="lumina-sugestao">
          <div className="lumina-sugestao-header">
            <span 
              className="lumina-eco-badge"
              style={{ backgroundColor: eco.cor }}
            >
              {eco.nome}
            </span>
            <span className="lumina-eco-area">{eco.area}</span>
          </div>
          <p className="lumina-sugestao-texto">{leitura.razao_sugestao}</p>
          <button className="lumina-btn-eco" style={{ backgroundColor: eco.cor }}>
            Explorar {eco.nome} →
          </button>
        </div>
      )}
      
      <div className="lumina-leitura-footer">
        <p className="lumina-leitura-nota">
          Esta leitura é um espelho, não um diagnóstico. 
          Tu és a especialista em ti.
        </p>
      </div>
      
      <div className="lumina-actions">
        <button className="lumina-btn-secondary" onClick={onVoltar}>
          Novo Check-in
        </button>
        <button className="lumina-btn-secondary" onClick={onVerHistorico}>
          Ver Histórico
        </button>
      </div>
    </div>
  )
}
