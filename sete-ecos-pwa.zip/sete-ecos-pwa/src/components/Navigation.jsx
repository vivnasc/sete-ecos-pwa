import { NavLink } from 'react-router-dom'
import './Navigation.css'

export default function Navigation() {
  return (
    <nav className="nav-bottom">
      <NavLink to="/" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
        <span className="nav-icon">🏠</span>
        <span className="nav-label">Início</span>
      </NavLink>
      
      <NavLink to="/lumina" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
        <span className="nav-icon">✨</span>
        <span className="nav-label">LUMINA</span>
      </NavLink>
      
      <NavLink to="/ecos" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
        <span className="nav-icon">🌀</span>
        <span className="nav-label">Ecos</span>
      </NavLink>
      
      <NavLink to="/perfil" className={({ isActive }) => isActive ? 'nav-item active' : 'nav-item'}>
        <span className="nav-icon">👤</span>
        <span className="nav-label">Perfil</span>
      </NavLink>
    </nav>
  )
}
