import { useState } from 'react'
import { auth } from '../lib/supabase'
import './Auth.css'

export default function Auth({ onAuth }) {
  const [mode, setMode] = useState('login') // login | register | forgot
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [success, setSuccess] = useState(null)
  
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    password: ''
  })
  
  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
    setError(null)
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)
    
    try {
      if (mode === 'login') {
        await auth.signIn(formData.email, formData.password)
        onAuth()
      } else if (mode === 'register') {
        if (!formData.nome.trim()) {
          throw new Error('Por favor, indica o teu nome')
        }
        await auth.signUp(formData.email, formData.password, formData.nome)
        setSuccess('Conta criada! Verifica o teu email para confirmar.')
        setMode('login')
      }
    } catch (err) {
      console.error(err)
      if (err.message.includes('Invalid login')) {
        setError('Email ou password incorrectos')
      } else if (err.message.includes('already registered')) {
        setError('Este email já está registado')
      } else {
        setError(err.message)
      }
    } finally {
      setLoading(false)
    }
  }
  
  return (
    <div className="auth-container">
      <div className="auth-header">
        <h1 className="auth-logo">SETE ECOS</h1>
        <p className="auth-tagline">Sistema de Transmutação Feminina</p>
      </div>
      
      <form className="auth-form" onSubmit={handleSubmit}>
        <h2 className="auth-title">
          {mode === 'login' ? 'Entrar' : 'Criar Conta'}
        </h2>
        
        {error && <div className="auth-error">{error}</div>}
        {success && <div className="auth-success">{success}</div>}
        
        {mode === 'register' && (
          <div className="auth-field">
            <label htmlFor="nome">Nome</label>
            <input
              type="text"
              id="nome"
              name="nome"
              value={formData.nome}
              onChange={handleChange}
              placeholder="O teu nome"
              required
            />
          </div>
        )}
        
        <div className="auth-field">
          <label htmlFor="email">Email</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email}
            onChange={handleChange}
            placeholder="o.teu@email.com"
            required
          />
        </div>
        
        <div className="auth-field">
          <label htmlFor="password">Password</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
            placeholder="••••••••"
            minLength={6}
            required
          />
        </div>
        
        <button 
          type="submit" 
          className="auth-button"
          disabled={loading}
        >
          {loading ? 'A processar...' : mode === 'login' ? 'Entrar' : 'Criar Conta'}
        </button>
        
        <div className="auth-switch">
          {mode === 'login' ? (
            <p>
              Ainda não tens conta?{' '}
              <button type="button" onClick={() => setMode('register')}>
                Criar conta
              </button>
            </p>
          ) : (
            <p>
              Já tens conta?{' '}
              <button type="button" onClick={() => setMode('login')}>
                Entrar
              </button>
            </p>
          )}
        </div>
      </form>
      
      <div className="auth-footer">
        <p>Uma PWA. Sete caminhos. Uma travessia.</p>
      </div>
    </div>
  )
}
