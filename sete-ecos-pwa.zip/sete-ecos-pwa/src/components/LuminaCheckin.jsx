import { useState } from 'react'
import './Lumina.css'

// Configuração dos 7 inputs - alinhados com especificação v14
const INPUTS = [
  {
    id: 'corpo',
    pergunta: 'Como está o teu corpo hoje?',
    eco: 'VITALIS',
    opcoes: [
      { valor: 'pesado', label: 'Pesado', emoji: '🪨' },
      { valor: 'tenso', label: 'Tenso', emoji: '😤' },
      { valor: 'normal', label: 'Normal', emoji: '😐' },
      { valor: 'solto', label: 'Solto', emoji: '😌' },
      { valor: 'leve', label: 'Leve', emoji: '🦋' }
    ]
  },
  {
    id: 'passado',
    pergunta: 'Como está o teu passado hoje?',
    eco: 'SERENA',
    opcoes: [
      { valor: 'preso', label: 'Preso', emoji: '⛓️' },
      { valor: 'apesar', label: 'A pesar', emoji: '😔' },
      { valor: 'normal', label: 'Normal', emoji: '😐' },
      { valor: 'arrumado', label: 'Arrumado', emoji: '📦' },
      { valor: 'leve', label: 'Leve', emoji: '🕊️' }
    ]
  },
  {
    id: 'impulso',
    pergunta: 'Qual é o teu impulso agora?',
    eco: 'IGNIS',
    opcoes: [
      { valor: 'esconder', label: 'Esconder', emoji: '🙈' },
      { valor: 'parar', label: 'Parar', emoji: '✋' },
      { valor: 'nada', label: 'Nada', emoji: '😐' },
      { valor: 'decidir', label: 'Decidir', emoji: '🤔' },
      { valor: 'agir', label: 'Agir', emoji: '🚀' }
    ]
  },
  {
    id: 'futuro',
    pergunta: 'Como vês o futuro hoje?',
    eco: 'VENTIS',
    opcoes: [
      { valor: 'escuro', label: 'Escuro', emoji: '🌑' },
      { valor: 'pesado', label: 'Pesado', emoji: '☁️' },
      { valor: 'normal', label: 'Normal', emoji: '😐' },
      { valor: 'claro', label: 'Claro', emoji: '🌤️' },
      { valor: 'luminoso', label: 'Luminoso', emoji: '☀️' }
    ]
  },
  {
    id: 'mente',
    pergunta: 'Como está a tua mente?',
    eco: 'ECOA',
    opcoes: [
      { valor: 'caotica', label: 'Caótica', emoji: '🌪️' },
      { valor: 'barulhenta', label: 'Barulhenta', emoji: '📢' },
      { valor: 'normal', label: 'Normal', emoji: '😐' },
      { valor: 'calma', label: 'Calma', emoji: '🌊' },
      { valor: 'silenciosa', label: 'Silenciosa', emoji: '🧘' }
    ]
  },
  {
    id: 'energia',
    pergunta: 'Como está a tua energia?',
    eco: 'LUMINA',
    opcoes: [
      { valor: 'vazia', label: 'Vazia', emoji: '🔋' },
      { valor: 'baixa', label: 'Baixa', emoji: '🪫' },
      { valor: 'normal', label: 'Normal', emoji: '😐' },
      { valor: 'boa', label: 'Boa', emoji: '⚡' },
      { valor: 'cheia', label: 'Cheia', emoji: '✨' }
    ]
  },
  {
    id: 'espelho',
    pergunta: 'O que vês no espelho?',
    eco: 'IMAGO',
    opcoes: [
      { valor: 'invisivel', label: 'Invisível', emoji: '👻' },
      { valor: 'apagada', label: 'Apagada', emoji: '😶' },
      { valor: 'normal', label: 'Normal', emoji: '😐' },
      { valor: 'visivel', label: 'Visível', emoji: '👁️' },
      { valor: 'luminosa', label: 'Luminosa', emoji: '🌟' }
    ]
  }
]

export default function LuminaCheckin({ onComplete, cicloInfo }) {
  const [step, setStep] = useState(0)
  const [respostas, setRespostas] = useState({})
  const [notaLivre, setNotaLivre] = useState('')
  
  const inputActual = INPUTS[step]
  const totalSteps = INPUTS.length
  const progresso = ((step + 1) / (totalSteps + 1)) * 100
  
  const handleSelect = (valor) => {
    setRespostas({ ...respostas, [inputActual.id]: valor })
    
    // Avançar automaticamente após selecção
    setTimeout(() => {
      if (step < totalSteps - 1) {
        setStep(step + 1)
      } else {
        setStep(totalSteps) // Ir para nota livre
      }
    }, 300)
  }
  
  const handleBack = () => {
    if (step > 0) setStep(step - 1)
  }
  
  const handleSubmit = () => {
    const checkinData = {
      ...respostas,
      nota_livre: notaLivre || null,
      fase_ciclo: cicloInfo?.fase || null,
      dia_ciclo: cicloInfo?.dia || null,
      data: new Date().toISOString().split('T')[0]
    }
    onComplete(checkinData)
  }
  
  // Ecrã de nota livre (último passo)
  if (step === totalSteps) {
    return (
      <div className="lumina-checkin fade-in">
        <div className="lumina-progress">
          <div className="lumina-progress-bar" style={{ width: '100%' }} />
        </div>
        
        <div className="lumina-question">
          <span className="lumina-step">Opcional</span>
          <h2>Queres deixar uma nota?</h2>
          <p className="lumina-hint">Algo que queiras lembrar sobre este momento</p>
        </div>
        
        <textarea
          className="lumina-nota"
          value={notaLivre}
          onChange={(e) => setNotaLivre(e.target.value)}
          placeholder="Escreve aqui se quiseres..."
          rows={4}
        />
        
        <div className="lumina-actions">
          <button className="lumina-btn-secondary" onClick={handleBack}>
            ← Voltar
          </button>
          <button className="lumina-btn-primary" onClick={handleSubmit}>
            Ver Leitura ✨
          </button>
        </div>
      </div>
    )
  }
  
  return (
    <div className="lumina-checkin fade-in">
      <div className="lumina-progress">
        <div className="lumina-progress-bar" style={{ width: `${progresso}%` }} />
      </div>
      
      <div className="lumina-question">
        <span className="lumina-step">{step + 1} de {totalSteps}</span>
        <h2>{inputActual.pergunta}</h2>
        <span className="lumina-eco-tag">{inputActual.eco}</span>
      </div>
      
      <div className="lumina-options">
        {inputActual.opcoes.map((opcao) => (
          <button
            key={opcao.valor}
            className={`lumina-option ${respostas[inputActual.id] === opcao.valor ? 'selected' : ''}`}
            onClick={() => handleSelect(opcao.valor)}
          >
            <span className="lumina-option-emoji">{opcao.emoji}</span>
            <span className="lumina-option-label">{opcao.label}</span>
          </button>
        ))}
      </div>
      
      {step > 0 && (
        <button className="lumina-btn-back" onClick={handleBack}>
          ← Voltar
        </button>
      )}
    </div>
  )
}
